# LLM-Based Legal Clause Risk Detector

A Flask web application that accepts contract text or TXT/PDF/DOCX files, analyzes clauses, highlights possible risks, and stores reports in SQLite.

## Features
- Upload TXT, PDF and DOCX files or paste contract text.
- LLM-based analysis through the OpenAI API.
- Clearly labelled local phrase-matching demo mode if no API key is configured.
- Risk categories, explanations, suggested actions and missing/unclear terms.
- Analysis history stored in SQLite.

## Requirements
- Python 3.10+
- An OpenAI API key for LLM analysis (optional for demo mode).

## Run locally

1. Extract the ZIP and open a terminal in this project folder.
2. Create and activate a virtual environment:

   Windows:
   ```bash
   python -m venv venv
   venv\Scripts\activate
   ```

   macOS/Linux:
   ```bash
   python3 -m venv venv
   source venv/bin/activate
   ```

3. Install packages:
   ```bash
   pip install -r requirements.txt
   ```

4. Copy `.env.example` to `.env` and add your API key:
   ```env
   OPENAI_API_KEY=your_actual_api_key
   OPENAI_MODEL=gpt-4o-mini
   FLASK_SECRET_KEY=use-a-long-random-value
   ```

   If you leave the API key empty, the app runs in demo mode. Demo mode is not LLM analysis.

5. Start the app:
   ```bash
   python app.py
   ```

6. Open `http://127.0.0.1:5000` in your browser.

## Project structure

```text
legal_clause_risk_detector/
├── app.py
├── analyzer.py
├── requirements.txt
├── .env.example
├── README.md
├── templates/
│   ├── base.html
│   ├── index.html
│   ├── result.html
│   └── history.html
└── static/
    └── style.css
```

## How it works
1. User uploads a contract or pastes text.
2. `app.py` validates the file and extracts its text.
3. `analyzer.py` sends the text to the configured LLM with a structured JSON output instruction.
4. The result includes overall risk, flagged clauses, explanations, suggested actions and unclear terms.
5. SQLite stores the report and the user can view it later in History.

## Important safeguards / limitations
- This is an educational project and a preliminary review aid, not a lawyer or legal advice.
- The model can miss important legal issues or flag clauses incorrectly. Always have a qualified legal professional review important agreements.
- Do not upload confidential, personal, privileged or sensitive documents unless you have permission and have reviewed the API provider's data handling terms.
- The demo phrase matcher is intentionally basic and must not be presented as equivalent to LLM analysis.
- Before production deployment, add authentication, CSRF protection, file size limits, secure secret management, access controls, retention/deletion policies, logging controls and stronger document parsing.
- This starter app stores extracted document text in a local SQLite database. Protect the database file and delete it when no longer needed.
