import os
import sqlite3
import json
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from werkzeug.utils import secure_filename
from dotenv import load_dotenv
from analyzer import analyze_document, extract_text

load_dotenv()
app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET_KEY", "change-this-development-secret")
DB_PATH = os.getenv("DATABASE_PATH", "legal_risk.db")
ALLOWED_EXTENSIONS = {"txt", "pdf", "docx"}

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with get_db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS analyses (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                filename TEXT NOT NULL,
                created_at TEXT NOT NULL,
                overall_risk TEXT,
                result_json TEXT NOT NULL,
                source_text TEXT
            )
        """)

def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route("/")
def index():
    with get_db() as conn:
        recent = conn.execute(
            "SELECT id, filename, created_at, overall_risk FROM analyses ORDER BY id DESC LIMIT 8"
        ).fetchall()
    return render_template("index.html", recent=recent)

@app.route("/analyze", methods=["POST"])
def analyze():
    uploaded = request.files.get("document")
    pasted_text = request.form.get("document_text", "").strip()
    filename = "Pasted text"

    if uploaded and uploaded.filename:
        if not allowed_file(uploaded.filename):
            flash("Upload a TXT, PDF, or DOCX file.", "error")
            return redirect(url_for("index"))
        filename = secure_filename(uploaded.filename)
        try:
            document_text = extract_text(uploaded)
        except Exception as exc:
            flash(f"Could not read the document: {exc}", "error")
            return redirect(url_for("index"))
    else:
        document_text = pasted_text

    if len(document_text.strip()) < 40:
        flash("Please upload a document or paste at least 40 characters of text.", "error")
        return redirect(url_for("index"))

    try:
        result = analyze_document(document_text)
    except Exception as exc:
        flash(f"Analysis failed: {exc}", "error")
        return redirect(url_for("index"))

    with get_db() as conn:
        cur = conn.execute(
            "INSERT INTO analyses(filename, created_at, overall_risk, result_json, source_text) VALUES (?, ?, ?, ?, ?)",
            (filename, datetime.now().strftime("%Y-%m-%d %H:%M"), result.get("overall_risk", "Unknown"),
             json.dumps(result), document_text[:50000])
        )
        analysis_id = cur.lastrowid
    return redirect(url_for("result", analysis_id=analysis_id))

@app.route("/result/<int:analysis_id>")
def result(analysis_id):
    with get_db() as conn:
        row = conn.execute("SELECT * FROM analyses WHERE id = ?", (analysis_id,)).fetchone()
    if not row:
        flash("Analysis not found.", "error")
        return redirect(url_for("index"))
    result_data = json.loads(row["result_json"])
    return render_template("result.html", record=row, result=result_data)

@app.route("/history")
def history():
    with get_db() as conn:
        rows = conn.execute("SELECT id, filename, created_at, overall_risk FROM analyses ORDER BY id DESC").fetchall()
    return render_template("history.html", rows=rows)

@app.route("/delete/<int:analysis_id>", methods=["POST"])
def delete(analysis_id):
    with get_db() as conn:
        conn.execute("DELETE FROM analyses WHERE id = ?", (analysis_id,))
    flash("Analysis deleted.", "success")
    return redirect(url_for("history"))

@app.route("/health")
def health():
    return jsonify({"status": "ok"})

init_db()

if __name__ == "__main__":
    app.run(debug=os.getenv("FLASK_DEBUG", "true").lower() == "true")
